import { Workbook } from 'exceljs';
import { GridServiceService } from './grid-service.service';
import { Component } from '@angular/core';
import { DecimalPipe, DatePipe } from '@angular/common';
import { AllCommunityModules, ValueFormatterService } from '@ag-grid-community/all-modules';
import { ExportService } from './_services/export.service';
import * as fs from 'file-saver';
import * as moment from 'moment';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'angular-agGrid-example';
  private gridApi;
  private gridColumnApi;
  public modules = AllCommunityModules;
  private columnDefs;
  private rowData;
  private excelStyles;
  constructor(private gridService: GridServiceService,
    private dateFormatter: DatePipe,
    private exportService: ExportService,
    private numberFormatter: DecimalPipe) {
  }

  onBtnExport(): void {
    const params = {
      columnGroups: true,
      allColumns: true,
      fileName: 'filename_of_your_choice',
      columnSeparator: this.rowData.value
    };
    this.gridApi.exportDataAsCsv(params);
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridService.getGridData().subscribe((data: any) => {
      if (data && data.length) {
        this.columnDefs = [...Object.entries(data[0]).map(
          (x: any) => {
            return {
              headerName: x[0].toUpperCase(),
              field: x[0],
              ... !isNaN(x[1]) && {
                valueFormatter: (data) => this.numberFormatter.transform(data.value, '1.2-2'),
                cellClass: "rawValue",
                type: 'number'
              },
              ...moment(x[1], moment.ISO_8601, true).isValid() && {
                valueFormatter: (data) => this.dateFormatter.transform(data.value, 'yyyy-dd-mm'),
                type: 'date'
              }
            }
          }
        )]
        this.rowData = data;
      } else {
        this.columnDefs = []
        this.rowData = []
      }
    })
  }
  onFirstDataRendered(params) {
    params.api.sizeColumnsToFit();
  }

  export() {
    var workbook = new Workbook();
    var worksheet = workbook.addWorksheet('My Sheet');
    worksheet.columns = this.columnDefs.map((x: any) => ({
      header: x.headerName,
      key: x.field,
      ...x.type === 'date' && { width: 15, style: { numFmt: 'MM-dd-yyyy' } },
      ...x.type === 'number' && {
        width: 15, style: { numFmt: '#,##0.00' }
      }
    }))
    console.log(worksheet.columns);
    worksheet.addRows(this.rowData.slice(0, 20).map(x => {
      return {
        ...x,
      }
    }))
    workbook.xlsx.writeBuffer().then((data) => {
      let blob = new Blob([data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      fs.saveAs(blob, 'CarData.xlsx');
    });
  }
}


